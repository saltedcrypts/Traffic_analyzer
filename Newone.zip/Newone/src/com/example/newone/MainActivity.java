package com.example.newone;

import android.app.Activity;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends Activity 
{ 
	Context context; 
	GPSTracker gps;
	@Override 
	protected void onCreate(Bundle savedInstanceState) 
	{ 
		super.onCreate(savedInstanceState); 
		setContentView(R.layout.activity_main); 
		context=this.getApplicationContext();
		gps = new GPSTracker(this.getApplicationContext(),MainActivity.this);
		Toast.makeText(context, gps.getLatitude()+" "+gps.getLongitude(), Toast.LENGTH_LONG).show();
		// Acquire a reference to the system Location Manager 
		LocationManager locationManager = (LocationManager) this .getSystemService(Context.LOCATION_SERVICE); 
		// Define a listener that responds to location updates 
		LocationListener locationListener = new LocationListener() 
		{ 
			public void onLocationChanged(Location location) 
			{ 
				
				Toast.makeText(context, "Current speed:" + location.getSpeed()+" Latitude:"+location.getLatitude()+" Longitude: "+location.getLongitude(), Toast.LENGTH_SHORT).show(); 
				} 
			public void onStatusChanged(String provider, int status, Bundle extras) 
			{ } 
			public void onProviderEnabled(String provider) { } 
			public void onProviderDisabled(String provider) { } 
			}; 
			locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener); 
			}
	public void showspeed(float speed,double lati,double longi) {
		// TODO Auto-generated method stub
		Toast.makeText(context, "Current speed:" + speed+" Latitude:"+lati+" Longitude: "+longi, Toast.LENGTH_SHORT).show(); 
	}
	
	}



