package com.example.newone;

import android.app.Activity;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity 
{ 
	Context context; 
	GPSTracker gps;
	TextView latitude_text,longitude_text,speed_text;
	double prev_lati=0.0,prev_longi=0.0;
	long millis=0;
	@Override 
	protected void onCreate(Bundle savedInstanceState) 
	{ 
		super.onCreate(savedInstanceState); 
		setContentView(R.layout.activity_main); 
		context=this.getApplicationContext();
		latitude_text=(TextView)findViewById(R.id.latitude);
		longitude_text=(TextView)findViewById(R.id.longitude);
		speed_text=(TextView)findViewById(R.id.speed);
		gps = new GPSTracker(this.getApplicationContext(),MainActivity.this);
		//Toast.makeText(context, gps.getLatitude()+" "+gps.getLongitude(), Toast.LENGTH_LONG).show();
			latitude_text.setText("Latitude: "+gps.getLatitude());
			longitude_text.setText("Longitude: "+gps.getLongitude());
			prev_lati=gps.getLatitude();
			prev_longi=gps.getLongitude();
			 millis = System.currentTimeMillis();
			 speed_text.setText("Speed: 0 m/s");
			 new Handler().postDelayed(new Runnable() {
			      @Override
			      public void run() {

			       showspeed(0,gps.getLatitude(),gps.getLongitude());
			      }
			    }, 3000);
	}
	//tried speed from gps location (location.getSpeed() but returning 0.0
	public void showspeed(float speed,double lati,double longi) {
		// TODO Auto-generated method stub
		//Toast.makeText(context, "From Location: Current speed:" + speed+" Latitude:"+lati+" Longitude: "+longi, Toast.LENGTH_SHORT).show(); 
		
			latitude_text.setText("Latitude: "+lati);
			longitude_text.setText("Longitude: "+longi);
			if(prev_lati==0.0){
				prev_lati=lati;
			}
			if(prev_longi==0.0){
				prev_longi=longi;
			}
			double dist=calculateDistance(prev_lati,prev_longi,lati,longi);
			
				speed_text.setText("Speed: "+(dist)/3+" m/s");
			millis=System.currentTimeMillis();
			prev_lati=lati;
			prev_longi=longi;
			
	
		new Handler().postDelayed(new Runnable() {
		      @Override
		      public void run() {

		       showspeed(0,gps.getLatitude(),gps.getLongitude());
		      }
		    }, 3000);
	}
	private static double calculateDistance(double lat1, double lng1, double lat2, double lng2) {
	 /*   double dLat = Math.toRadians(lat2 - lat1);
	    double dLon = Math.toRadians(lng2 - lng1);
	    double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
	            + Math.cos(Math.toRadians(lat1))
	            * Math.cos(Math.toRadians(lat2)) * Math.sin(dLon / 2)
	            * Math.sin(dLon / 2);
	    double c = 2 * Math.asin(Math.sqrt(a));
	    long distanceInMeters = Math.round(6371000 * c);
	    return distanceInMeters; */
		
		//roughly 1 degree = 111km
		double latidiff=Math.abs(lat1-lat2);
		double longidiff=Math.abs(lng1-lng2);
		double res=Math.sqrt(latidiff*111000*latidiff*111000*longidiff*111000*longidiff*111000);
		return res;
	}
	
	}



